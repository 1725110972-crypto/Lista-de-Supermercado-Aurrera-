# Productos del Supermercado (Aurrera) - version simple

Mismo concepto y misma estructura que el proyecto de agenda (web.py +
controllers + views + sql), pero aplicado al TDA de lista ordenada de
productos.

## Estructura

```
aurrera_simple/
├── app.py                       # rutas (igual que temporal/app.py, para correr)
├── controllers/
│   ├── index.py                 # pantalla de inicio
│   └── lista_productos.py       # consulta SQL + ordena con el TDA
├── tda/
│   └── lista_ordenada.py        # el TDA: lista ordenada
├── sql/
│   ├── script.sql               # CREATE TABLE + INSERT de 25 productos
│   └── aurrera.db                # base de datos ya generada con esos 25 productos
├── temporal/
│   └── app.py                   # copia de referencia (igual que en agenda)
├── views/
│   ├── layout.html
│   ├── index.html
│   └── lista_productos.html
└── requirements.txt
```

## Como correrlo

```bash
pip install -r requirements.txt
python3 app.py
```

Esto levanta el servidor (por default en `http://0.0.0.0:8080`). Entra a
`/lista_productos` para ver la lista, elegir el criterio de orden
(categoria, precio, nombre, etc.) y buscar por texto.

## El TDA

`tda/lista_ordenada.py` tiene la clase `ListaOrdenada`: cada producto se
inserta en la posicion que le corresponde (no al final), y por eso la
lista siempre queda ordenada. `controllers/lista_productos.py` es quien
la usa: trae los productos de SQLite y los va insertando uno por uno en
el TDA antes de mandarlos a la vista.

## Nota sobre compatibilidad

`web.py` es un framework viejo que necesita el modulo `cgi`, el cual ya
no viene incluido en Python 3.13+. Por eso `requirements.txt` incluye
`legacy-cgi`, que repone ese modulo. Si al instalar te sale un error de
`cgi`, corre primero:

```bash
pip install legacy-cgi
pip install -r requirements.txt
```
