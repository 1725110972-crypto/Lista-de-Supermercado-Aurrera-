CREATE TABLE productos(
    id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
    categoria TEXT NOT NULL,
    nombre TEXT NOT NULL,
    precio REAL NOT NULL,
    fecha_caducidad TEXT NOT NULL,
    unidad_medida TEXT NOT NULL,
    cantidad_inventario INTEGER NOT NULL,
    marca TEXT NOT NULL,
    codigo_barras TEXT NOT NULL
);

INSERT INTO productos
(categoria, nombre, precio, fecha_caducidad, unidad_medida, cantidad_inventario, marca, codigo_barras)
VALUES
-- Lacteos
('Lacteos', 'Leche entera', 26.50, '2026-09-25', '1 L', 120, 'Lala', '7501020501234'),
('Lacteos', 'Yogurt natural', 32.00, '2026-09-18', '1 L', 80, 'Danone', '7501020501241'),
('Lacteos', 'Queso panela', 65.90, '2026-09-15', '400 g', 45, 'Chilchota', '7501020501258'),
('Lacteos', 'Mantequilla', 48.00, '2026-11-10', '90 g', 60, 'Gloria', '7501020501265'),

-- Carnes
('Carnes', 'Pechuga de pollo', 89.00, '2026-09-12', '1 kg', 35, 'Bachoco', '7501030601234'),
('Carnes', 'Jamon de pavo', 55.50, '2026-09-20', '250 g', 70, 'FUD', '7501030601241'),
('Carnes', 'Carne molida de res', 130.00, '2026-09-13', '1 kg', 25, 'SuKarne', '7501030601258'),
('Carnes', 'Chorizo', 42.00, '2026-10-01', '250 g', 50, 'San Rafael', '7501030601265'),

-- Hogar
('Hogar', 'Papel higienico (4 rollos)', 58.00, '2028-01-01', '4 pza', 200, 'Petalo', '7501040701234'),
('Hogar', 'Servilletas', 22.50, '2028-01-01', '1 paquete', 150, 'Kleenex', '7501040701241'),
('Hogar', 'Foco LED', 39.00, '2030-01-01', '1 pza', 90, 'Philips', '7501040701258'),

-- Limpieza
('Limpieza', 'Jabon liquido para trastes', 34.00, '2027-06-01', '750 ml', 110, 'Salvo', '7501050801234'),
('Limpieza', 'Cloro', 24.00, '2027-08-01', '1 L', 95, 'Cloralex', '7501050801241'),
('Limpieza', 'Detergente en polvo', 89.90, '2027-12-01', '1 kg', 65, 'Ariel', '7501050801258'),

-- Bebidas
('Bebidas', 'Agua natural', 15.00, '2027-03-01', '1.5 L', 300, 'Ciel', '7501060901234'),
('Bebidas', 'Refresco de cola', 20.00, '2026-12-01', '600 ml', 180, 'Coca-Cola', '7501060901241'),
('Bebidas', 'Jugo de naranja', 28.50, '2026-10-15', '1 L', 75, 'Jumex', '7501060901258'),

-- Panaderia
('Panaderia', 'Pan de caja blanco', 36.00, '2026-09-16', '680 g', 55, 'Bimbo', '7501071001234'),
('Panaderia', 'Panque de vainilla', 29.00, '2026-09-22', '435 g', 40, 'Marinela', '7501071001241'),

-- Frutas y Verduras
('Frutas y Verduras', 'Manzana roja', 42.00, '2026-09-19', '1 kg', 100, 'Granel', '7501081101234'),
('Frutas y Verduras', 'Platano', 18.00, '2026-09-14', '1 kg', 130, 'Granel', '7501081101241'),
('Frutas y Verduras', 'Jitomate', 24.00, '2026-09-13', '1 kg', 90, 'Granel', '7501081101258'),

-- Abarrotes
('Abarrotes', 'Arroz', 32.00, '2027-05-01', '1 kg', 140, 'Verde Valle', '7501091201234'),
('Abarrotes', 'Frijol negro', 35.00, '2027-04-01', '1 kg', 110, 'La Sierra', '7501091201241'),
('Abarrotes', 'Aceite vegetal', 48.00, '2027-07-01', '1 L', 85, '1-2-3', '7501091201258');

SELECT * FROM productos;
