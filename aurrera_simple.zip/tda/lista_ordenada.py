# -*- coding: utf-8 -*-
"""
TDA: Lista Ordenada
--------------------
Cada producto que se inserta se coloca en la posicion que le corresponde
segun un criterio de orden (la 'clave'), en vez de agregarse al final.
Asi la lista siempre queda ordenada y cada producto ocupa una posicion
determinada, igual que la lista de alumnos ordenada por apellido que
puso de ejemplo el profesor.
"""


class ListaOrdenada:
    def __init__(self, clave):
        """
        clave: funcion que recibe un producto (dict) y regresa el valor
               usado para decidir su posicion en la lista.
               Ejemplo: clave = lambda p: p['precio']
        """
        self._datos = []
        self._clave = clave

    def __len__(self):
        return len(self._datos)

    def insertar(self, elemento):
        """Inserta manteniendo el orden (no se agrega al final)."""
        valor = self._clave(elemento)
        posicion = 0
        while posicion < len(self._datos) and self._clave(self._datos[posicion]) <= valor:
            posicion += 1
        self._datos.insert(posicion, elemento)
        return posicion

    def obtener_todos(self):
        return list(self._datos)

    def buscar_por_valor(self, valor):
        """Busqueda binaria: regresa los productos cuya clave sea igual a 'valor'."""
        izquierda, derecha = 0, len(self._datos) - 1
        encontrado = -1
        while izquierda <= derecha:
            medio = (izquierda + derecha) // 2
            valor_medio = self._clave(self._datos[medio])
            if valor_medio == valor:
                encontrado = medio
                break
            elif valor_medio < valor:
                izquierda = medio + 1
            else:
                derecha = medio - 1

        if encontrado == -1:
            return []

        resultados = [self._datos[encontrado]]
        izq = encontrado - 1
        while izq >= 0 and self._clave(self._datos[izq]) == valor:
            resultados.insert(0, self._datos[izq])
            izq -= 1
        der = encontrado + 1
        while der < len(self._datos) and self._clave(self._datos[der]) == valor:
            resultados.append(self._datos[der])
            der += 1
        return resultados

    def buscar_por_rango(self, minimo, maximo):
        """Regresa los productos cuya clave esta entre minimo y maximo (inclusive)."""
        return [e for e in self._datos if minimo <= self._clave(e) <= maximo]
