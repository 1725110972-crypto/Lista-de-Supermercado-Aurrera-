import web

urls = (
    '/', 'controllers.index.Index',
    '/lista_productos', 'controllers.lista_productos.ListaProductos',
)
app = web.application(urls, globals())

if __name__ == "__main__":
    app.run()
