import web
import sqlite3

from tda.lista_ordenada import ListaOrdenada

render = web.template.render('views', base='layout')

# Reglas de orden disponibles: clave interna -> etiqueta que se muestra
REGLAS = {
    'categoria': 'Categoria',
    'nombre': 'Nombre del producto',
    'precio': 'Precio',
    'fecha_caducidad': 'Fecha de caducidad',
    'unidad_medida': 'Unidad de medida',
    'cantidad_inventario': 'Cantidad en inventario',
    'marca': 'Marca',
    'codigo_barras': 'Codigo de barras',
}


class ListaProductos:

    def obtenerProductos(self, texto_buscado=''):
        try:
            # Conecta a la base de datos
            conn = sqlite3.connect('sql/aurrera.db')
            cursor = conn.cursor()

            if texto_buscado:
                patron = f"%{texto_buscado}%"
                cursor.execute("""
                    SELECT * FROM productos
                    WHERE nombre LIKE ? COLLATE NOCASE
                       OR marca LIKE ? COLLATE NOCASE
                       OR categoria LIKE ? COLLATE NOCASE
                """, (patron, patron, patron))
            else:
                cursor.execute("SELECT * FROM productos;")

            # Crea un array vacio para almacenar los registros
            productos = []
            # Almacena cada registro en un diccionario
            for row in cursor.fetchall():
                producto = {
                    'id_producto': row[0],
                    'categoria': row[1],
                    'nombre': row[2],
                    'precio': row[3],
                    'fecha_caducidad': row[4],
                    'unidad_medida': row[5],
                    'cantidad_inventario': row[6],
                    'marca': row[7],
                    'codigo_barras': row[8],
                }
                # Agrega el diccionario creado al array
                productos.append(producto)

            return productos
        except sqlite3.Error as error:
            print(f"ERROR 100: {error.args}")
            return []
        except Exception as error:
            print(f"ERROR 101: {error.args}")
            return []
        finally:
            conn.close()

    def ordenarProductos(self, productos, criterio):
        """Usa el TDA ListaOrdenada para acomodar los productos por criterio."""
        if criterio not in REGLAS:
            criterio = 'categoria'

        clave = lambda p: p[criterio]
        lista = ListaOrdenada(clave)
        for producto in productos:
            lista.insertar(producto)
        return lista.obtener_todos()

    def GET(self):
        entrada = web.input(criterio='categoria', q='')
        criterio = entrada.criterio
        texto_buscado = entrada.q.strip()

        productos = self.obtenerProductos(texto_buscado)
        productos = self.ordenarProductos(productos, criterio)

        print(productos)
        return render.lista_productos(productos, criterio, REGLAS, texto_buscado)
